#!/sbin/sh
# 
# /system/addon.d/60-volte.sh
# OTA survival for VoLTE patch
# By Sudeep.Duhoon (facebook)
#

. /tmp/backuptool.functions

list_files() {
cat <<EOF
addon.d/60-volte.sh
bin/ims_rtp_daemon
bin/imscmservice
bin/imsdatadaemon
bin/imsqmidaemon
etc/permissions/imscm.xml
framework/imscmlibrary.jar
framework/qcnvitems.jar
framework/qcrilhook.jar
framework/rcsimssettings.jar
lib/libshims_ims.so
lib64/libprotobuf-cpp-full.so
lib64/libshims_ims.so
priv-app/qcrilmsgtunnel/qcrilmsgtunnel.apk
vendor/app/ims/ims.apk
vendor/app/imssettings/imssettings.apk
vendor/lib64/libcneapiclient.so
vendor/lib64/lib-dplmedia.so
vendor/lib64/lib-imscamera.so
vendor/lib64/libimscamera_jni.so
vendor/lib64/lib-imsdpl.so
vendor/lib64/libimsmedia_jni.so
vendor/lib64/lib-imsqimf.so
vendor/lib64/lib-imsrcs.so
vendor/lib64/lib-imsrcscm.so
vendor/lib64/lib-imsrcscmclient.so
vendor/lib64/lib-ims-rcscmjni.so
vendor/lib64/lib-imsrcscmservice.so
vendor/lib64/lib-imss.so
vendor/lib64/lib-imsSDP.so
vendor/lib64/lib-imsvt.so
vendor/lib64/lib-imsxml.so
vendor/lib64/librcc.so
vendor/lib64/lib-rcsimssjni.so
vendor/lib64/lib-rcsjni.so
vendor/lib64/libril-qc-qmi-1.so
vendor/lib64/libril-qc-radioconfig.so
vendor/lib64/libril-qcril-hook-oem.so
vendor/lib64/lib-rtpcommon.so
vendor/lib64/lib-rtpcore.so
vendor/lib64/lib-rtpdaemoninterface.so
vendor/lib64/lib-rtpsl.so
vendor/lib64/libvoice-svc.so
EOF
}

case "$1" in
  backup)
    list_files | while read FILE DUMMY; do
      backup_file $S/"$FILE"
    done
  ;;
  restore)
    list_files | while read FILE REPLACEMENT; do
      R=""
      [ -n "$REPLACEMENT" ] && R="$S/$REPLACEMENT"
      [ -f "$C/$S/$FILE" ] && restore_file $S/"$FILE" "$R"
    done
  ;;
  pre-backup)
    # Stub
  ;;
  post-backup)
    # Stub
  ;;
  pre-restore)
    # Stub
  ;;
  post-restore)
    # Stub
	sed -i 's:persist.radio.hw_mbn_update.*:persist.radio.hw_mbn_update=0:' /system/build.prop
	sed -i 's:persist.radio.sw_mbn_update=.*:persist.radio.sw_mbn_update=0:' /system/build.prop
	sed -i 's:persist.radio.VT_HYBRID_ENABLE=.*:persist.radio.VT_HYBRID_ENABLE=1:' /system/build.prop
	sed -i 's:persist.audio.fluence.voicecall=.*:persist.audio.fluence.voicecall=false:' /system/build.prop
	sed -i 's:ro.qc.sdk.audio.fluencetype=.*:ro.qc.sdk.audio.fluencetype=none:' /system/build.prop
	sed -i 's:ro.telephony.default_network=.*:ro.telephony.default_network=22,20:' /system/build.prop
	sed -i 's:telephony.lteOnCdmaDevice=.*:telephony.lteOnCdmaDevice=1:' /system/build.prop
	sed -i 's:persist.audio.fluence.voicerec=.*:persist.audio.fluence.voicerec=false:' /system/build.prop
	echo "" >> /system/build.prop
	echo "# IMS" >> /system/build.prop
	echo "persist.dbg.volte_avail_ovr=1" >> /system/build.prop
	echo "persist.dbg.vt_avail_ovr=1" >> /system/build.prop
	echo "" >> /system/build.prop
  ;;
esac
